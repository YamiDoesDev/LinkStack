<label for='title' class='form-label'>{{__('messages.Heading Text:')}}</label>
<input type='text' name='title' value='{{$title}}' class='form-control' />