# A LinkStack Theme
Find more themes: https://github.com/JulianPrieber/llc-themes
                                                                                                                                                                         
*	Theme Name: PolySleek
*	Theme Version: 1.2
*	Theme Date: 23/02/2023 <!-- DD/MM/YYYY -->
*	Theme Author: JulianPrieber & Linkstack Team
*	Theme Author URI: https://github.com/JulianPrieber
*	Theme License: MIT
*	Source code: https://github.com/JulianPrieber/PolySleek


### Used assets:
* Built using:
* https://github.com/dhg/Skeleton
* License: MIT

*
* https://codepen.io/Saramazal/pen/LYyywNb
* License: MIT

*
* https://codepen.io/hendrysadrak/pen/VLMOMJ
* License: MIT
