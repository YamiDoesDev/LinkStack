<div class="container d-flex align-items-center justify-content-center" style="height: 100vh;">
      <div class="col-sm-12 col-lg-6">
        {{ $slot }}
      </div>
</div>
  